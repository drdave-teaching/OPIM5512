
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Try to load California Housing from sklearn
try:
    from sklearn.datasets import fetch_california_housing
except Exception as e:
    raise RuntimeError("scikit-learn is required. Try: pip install scikit-learn") from e

# Resolve repo paths (works if you run from repo root or /src)
REPO = Path.cwd()
# Walk up until we see a .git (repo root) or stop
while not (REPO / ".git").exists() and REPO.parent != REPO:
    REPO = REPO.parent

DATA = REPO / "data"
FIGS = REPO / "figs"
DATA.mkdir(parents=True, exist_ok=True)
FIGS.mkdir(parents=True, exist_ok=True)

# Load dataset
cal = fetch_california_housing(as_frame=True)
df = cal.frame.rename(columns={"MedHouseVal": "MedHomeVal_100k"})
df["MedHomeVal_$"] = df["MedHomeVal_100k"] * 100_000

# Save tables
summary = df.describe(include="all").T
summary.to_csv(DATA / "summary.csv")
nulls = df.isna().sum().sort_values(ascending=False)
nulls.to_csv(DATA / "null_counts.csv")

# Pick one numeric column for a histogram (default MedInc if present)
num_cols = df.select_dtypes(include=np.number).columns.tolist()
col = "MedInc" if "MedInc" in num_cols else num_cols[0]

# Histogram
plt.figure()
df[col].hist(bins=30)
plt.title(f"Histogram of {col}")
plt.xlabel(col)
plt.ylabel("count")
plt.tight_layout()
hist_path = FIGS / f"hist_{col}.png"
plt.savefig(hist_path, dpi=150)

# Scatter (if both columns exist)
if {"MedInc", "MedHomeVal_$"}.issubset(df.columns):
    plt.figure()
    plt.scatter(df["MedInc"], df["MedHomeVal_$"], s=5, alpha=0.5)
    plt.xlabel("Median Income (10k units in original)")
    plt.ylabel("Median Home Value ($)")
    plt.title("Income vs Home Value")
    plt.tight_layout()
    scatter_path = FIGS / "scatter_income_value.png"
    plt.savefig(scatter_path, dpi=150)

print("Saved:")
print(" -", DATA / "summary.csv")
print(" -", DATA / "null_counts.csv")
print(" -", hist_path)
if (FIGS / "scatter_income_value.png").exists():
    print(" -", FIGS / "scatter_income_value.png")
