# OPIM 5512 — Intro EDA Starter (Evergreen)

This tiny repo is for your first Git practice and a basic EDA on the **California Housing** dataset (from `scikit-learn`).  
You will **edit a file, commit, push**, then run a small EDA notebook and **commit/push** again.

## What you will do
1. **Edit this README:** add your name below and one sentence about your background. Commit and push.
2. **Install dependencies** in your local Python environment:
   - Windows (PowerShell):
     ```powershell
     pip install -r requirements.txt
     ```
   - macOS (Terminal / zsh):
     ```bash
     pip install -r requirements.txt
     ```
3. **Run the notebook:** open `notebooks/eda.ipynb` in VS Code and run all cells. It will:
   - Load the CA Housing dataset
   - Save a summary table to `data/summary.csv`
   - Save a nulls count table to `data/null_counts.csv`
   - Create at least one histogram and one scatter plot in `figs/`
4. **Commit & push the results.**
5. **Make one change** (e.g., pick a different numeric column for the histogram **or** change the number of bins),
   re-run the cell(s), then **commit & push** again.

## How to submit
- Push your changes and open a GitHub **Issue** titled **"A01 ready"** with 1–2 sentences on what you explored,
  and paste your latest **commit hash** (from `git log --oneline -1`).

## Your info (edit me, then commit & push)
- **Name:** _<your name here>_
- **One-liner about you:** _<one sentence>_

---

### Repo layout
```
.
├─ notebooks/
│  └─ eda.ipynb          # run this
├─ src/
│  └─ eda_basic.py       # optional script version (same logic as the notebook)
├─ data/                 # CSV outputs saved here
├─ figs/                 # PNG figures saved here
├─ requirements.txt
├─ .gitignore
└─ .gitattributes
```

### Notes
- Keep this repo **private** during the course.
- Use **meaningful commit messages**; small, frequent commits are better than huge ones.
- If you see line-ending warnings on Windows vs. Mac, the included `.gitattributes` handles it.
