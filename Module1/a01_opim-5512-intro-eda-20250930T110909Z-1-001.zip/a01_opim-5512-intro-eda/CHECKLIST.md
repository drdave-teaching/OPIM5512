# A01 Checklists

## Student checklist
- [ ] Cloned repo locally
- [ ] Edited README (name + one-liner), committed & pushed
- [ ] Installed dependencies (`pip install -r requirements.txt`)
- [ ] Ran `notebooks/eda.ipynb`
- [ ] `data/summary.csv` and `data/null_counts.csv` created
- [ ] At least one PNG saved in `figs/`
- [ ] Made one change (bins or column), re-ran, committed & pushed
- [ ] Opened Issue "A01 ready" with latest commit hash

## Quick grading checklist (instructor)
- [ ] README updated with name + one-liner
- [ ] Commit history shows small, meaningful commits
- [ ] CSVs present in `data/`
- [ ] PNGs present in `figs/`
- [ ] Notebook runs cleanly (no errors)
