
---
name: A02 task
about: Small, reviewable step for the A02 ping-pong
title: "A02-<nn> <short task>"
labels: ["A02"]
---

**Goal**
- (1–2 sentences)

**Acceptance criteria**
- [ ] Artifact(s) saved in `A02-collab/data` or `A02-collab/figs`
- [ ] 2–3 sentence note added to `A02-collab/README.md`
- [ ] Branch + PR opened; code runs

**Notes**
- (any context)
