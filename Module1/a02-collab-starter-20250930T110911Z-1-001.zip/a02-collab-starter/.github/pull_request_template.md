## What changed?
(1–2 sentences)

## Evidence
- [ ] Updated files in `A02-collab/data` or `A02-collab/figs`
- [ ] Short note in `A02-collab/README.md`

Closes #<issue-number>
